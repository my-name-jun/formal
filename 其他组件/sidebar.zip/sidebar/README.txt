A Pen created at CodePen.io. You can find this one at https://codepen.io/tanjinhai1653082552/pen/WZaGzM.

 Flat sidebar with animations, fadeouts, lots of pseudo elements and turquoise color.